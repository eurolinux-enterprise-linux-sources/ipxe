#ifndef _BITS_TIMER_H
#define _BITS_TIMER_H

/** @file
 *
 * ARM-specific timer API implementations
 *
 */

FILE_LICENCE ( GPL2_OR_LATER_OR_UBDL );

#endif /* _BITS_TIMER_H */
