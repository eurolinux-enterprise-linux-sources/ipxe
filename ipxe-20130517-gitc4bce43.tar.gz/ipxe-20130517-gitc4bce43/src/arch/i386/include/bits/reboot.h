#ifndef _BITS_REBOOT_H
#define _BITS_REBOOT_H

/** @file
 *
 * i386-specific reboot API implementations
 *
 */

FILE_LICENCE ( GPL2_OR_LATER );

#include <ipxe/bios_reboot.h>

#endif /* _BITS_REBOOT_H */
